package com.capgemini.flp.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.capgemini.flp.dto.Customer;
import com.capgemini.flp.exception.SignUpException;

@Repository
public class SignUpDao implements IntSignUpDao
{
	@Autowired
	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public boolean addCustomer(Customer customer) throws SignUpException {
		try
		{
			entityManager.persist(customer);
			return true;
		}catch(PersistenceException e) {
			throw new SignUpException(e.getMessage());
		}		
	}
}


