package com.capgemini.flp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.flp.dto.Admin;
import com.capgemini.flp.dto.Customer;
import com.capgemini.flp.exception.SignUpException;
import com.capgemini.flp.service.IntSignUpService;



@Controller
@RequestMapping(value="/signup")
public class SignUpController {
	
	@Autowired
	IntSignUpService signUpService;
	
	@RequestMapping(value="/customer")
	public ModelAndView customerForm() {
		Customer customer=new Customer();
		return new ModelAndView("customer","customer",customer);
	}
	
	@RequestMapping(value="/register" ,method=RequestMethod.POST)
	public ModelAndView addCustomer( @ModelAttribute(value="customer")Customer customer) 
	{
		try {
			boolean flag=signUpService.addCustomer(customer);
			String result;
			if(flag)
			{
				result="Your account is created successfully.!!";
			}else
			{
				result="An error occurred. Please try again";
			
			}	return new ModelAndView("customer_redirect","result",result);
			
		} catch (SignUpException e) {
			return new ModelAndView("status","status",e.getMessage());
		}
		
	}
	
/*	@RequestMapping(value="/admin")
	public ModelAndView adminForm()
	{
		Admin admin=new Admin();
		return new ModelAndView("admin","admin",admin);
	}
	*/
	
	
	
	
	
}
