package com.capgemini.flp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.flp.dto.Admin;
import com.capgemini.flp.dto.Customer;
import com.capgemini.flp.dto.Merchant;
import com.capgemini.flp.exception.SignUpException;
import com.capgemini.flp.service.IntSignUpService;



@Controller
@RequestMapping(value="/signup")
public class SignUpController {

	@Autowired
	IntSignUpService signUpService;

	
	// To display the customer application form
	@RequestMapping(value="/customer")
	public ModelAndView customerForm() {
		Customer customer=new Customer();
			return new ModelAndView("customer","customer",customer);
	}

	//To persist to the table in database
	@RequestMapping(value="/customerregister",method=RequestMethod.POST)
	public ModelAndView addCustomer( @ModelAttribute("customer")Customer customer) 
	{
		try {
			boolean flag=signUpService.addCustomer(customer);
			String result;
			if(flag)
			{
				result="Your account is created successfully.!!";
			}else
			{
				result="An error occurred. Please try again";

			}	return new ModelAndView("customer_redirect","result",result);

		} catch (SignUpException e) {
			return new ModelAndView("status","status",e.getMessage());
		}

	}
	// To display the admin application form
	@RequestMapping(value="/admin")
	public ModelAndView adminForm()
	{
		Admin admin=new Admin();
		return new ModelAndView("admin","admin",admin);
	}

	//To persist to the table in database
	@RequestMapping(value="/adminregister" ,method=RequestMethod.POST)
	public ModelAndView addAdmin(@ModelAttribute(value="admin")Admin admin)
	{
		try
		{
			boolean flag=signUpService.addAdmin(admin);
			String message;
			if(flag)
			{
				message="Welcome.!You are authenticated as admin";
			}else
			{
				message="Sorry! Try again";
			}
			return new ModelAndView("admin_redirect","message",message);
		}catch (SignUpException e) {
			return new ModelAndView("status","status",e.getMessage());
		}
	}
		
		
		
		// To display the merchant application form
		@RequestMapping(value="/merchant")
		public ModelAndView merchantForm()
		{
			Merchant merchant=new Merchant();
			return new ModelAndView("merchant","merchant",merchant);
		}

		//To persist to the table in database
		@RequestMapping(value="/merchantregister" ,method=RequestMethod.POST)
		public ModelAndView addMerchant(@ModelAttribute(value="merchant")Merchant merchant)
		{
			try
			{
				boolean flag=signUpService.addMerchant(merchant);
				String trade;
				if(flag)
				{
					trade="Welcome.!You are now a merchant";
				}else
				{
					trade="Sorry! Try again";
				}
				return new ModelAndView("merchant_redirect","trade",trade);
			}catch (SignUpException e) {
				return new ModelAndView("status","status",e.getMessage());
			}
			
		}
		
		
		
				


}
