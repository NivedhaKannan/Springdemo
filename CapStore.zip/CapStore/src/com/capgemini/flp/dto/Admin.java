package com.capgemini.flp.dto;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Table(name="admin_login")
@Entity

public class Admin {
	@Id
	private String email_Id;
	@NotNull
	private String password;
	private Integer phoneNumber;
	private String name;
	private String address;
}
