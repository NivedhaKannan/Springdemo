package com.capgemini.flp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.flp.dao.IntSignUpDao;
import com.capgemini.flp.dto.Admin;
import com.capgemini.flp.dto.Customer;
import com.capgemini.flp.dto.Merchant;
import com.capgemini.flp.dto.ThirdPartyMerchant;
import com.capgemini.flp.exception.SignUpException;

@Service
@Transactional
public class SignUpService implements IntSignUpService {

	 @Autowired
	 IntSignUpDao signUpDao;
	 
	 
	@Override
	public boolean addCustomer(Customer customer) throws SignUpException {
	
		return signUpDao.addCustomer(customer);
	}


	@Override
	public boolean addAdmin(Admin admin) throws SignUpException {
			return signUpDao.addAdmin(admin);
	}


	@Override
	public boolean addMerchant(Merchant merchant) throws SignUpException {
		return signUpDao.addMerchant(merchant);
	}


	@Override
	public boolean addThirdPartyMerchant(ThirdPartyMerchant thirdpartymerchant) throws SignUpException {
	   return signUpDao.addThirdPartyMerchant(thirdpartymerchant);
	}

}
