package com.capgemini.flp.service;

import com.capgemini.flp.dto.Customer;
import com.capgemini.flp.exception.SignUpException;

public interface IntSignUpService 
{

	public boolean addCustomer(Customer customer)throws SignUpException;
	
}
