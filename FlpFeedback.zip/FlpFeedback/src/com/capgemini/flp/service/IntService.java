package com.capgemini.flp.service;

import com.capgemini.flp.dto.Customer_Login;
import com.capgemini.flp.dto.Feedback;
import com.capgemini.flp.exception.FeedbackException;

public interface IntService {

	public boolean getFeedbackPage(Feedback feedback)throws FeedbackException;

}
