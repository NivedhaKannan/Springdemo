package com.capgemini.flp.dto;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.springframework.context.annotation.Configuration;


@Entity
@Table(name="feedback")
public class Feedback {
	@Id
	private int product_Id;
	@NotNull
	private String product_feedback;
	private double product_Rating;
	private String customer_emailId;
	private int ratingCount;
	private int averageCount;

	public int getProduct_Id() {
		return product_Id;
	}

	public void setProduct_Id(int product_Id) {
		this.product_Id = product_Id;
	}

	public String getProduct_feedback() {
		return product_feedback;
	}




	public void setProduct_feedback(String product_feedback) {
		this.product_feedback = product_feedback;
	}


	public double getProduct_Rating() {
		return product_Rating;
	}

	public void setProduct_Rating(double product_Rating) {
		this.product_Rating = product_Rating;
	}

	public String getCustomer_emailId() {
		return customer_emailId;
	}




	public void setCustomer_emailId(String customer_emailId) {
		this.customer_emailId = customer_emailId;
	}




	public int getRatingCount() {
		return ratingCount;
	}




	public void setRatingCount(int ratingCount) {
		this.ratingCount = ratingCount;
	}




	public int getAverageCount() {
		return averageCount;
	}




	public void setAverageCount(int averageCount) {
		this.averageCount = averageCount;
	}

	@Override
	public String toString() {
		return "Feedback [product_Id=" + product_Id + ", product_feedback="
				+ product_feedback + ", product_Rating=" + product_Rating
				+ ", customer_emailId=" + customer_emailId + ", ratingCount="
				+ ratingCount + ", averageCount=" + averageCount + "]";
	}





}