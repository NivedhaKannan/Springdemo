package com.capgemini.sec.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.sec.entity.CollegeEntity;

import com.capgemini.sec.myexception.Myexception;

@Repository
@Transactional
@Configuration
public class IDao implements IntDao {
	@Autowired
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public Integer create_student(CollegeEntity collegeEntity) throws Myexception {
		
		entityManager.persist(collegeEntity);
		return collegeEntity.getId();
	}

}
