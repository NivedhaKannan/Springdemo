package com.capgemini.sec.dao;

import com.capgemini.sec.entity.CollegeEntity;

import com.capgemini.sec.myexception.Myexception;

public interface IntDao {
	

	public Integer create_student(CollegeEntity collegeEntity) throws Myexception;
}
