package com.capgemini.sec.myexception;

public class Myexception extends Exception {
	
		private static final long serialVersionUID = 1L;
		private String status;
		
		public Myexception() {
			this.status="Unable to perform operation";
		}
		
		public Myexception(String status) {
			super(status);
		}

		public String getStatus() {
			return status;
		}

		@Override
		public String toString() {
			return "Myexception [status=" + status + "]";
		}
		
	}


