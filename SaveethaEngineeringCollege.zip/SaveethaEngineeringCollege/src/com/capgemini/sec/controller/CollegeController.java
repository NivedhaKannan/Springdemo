package com.capgemini.sec.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.sec.model.CollegeModel;
import com.capgemini.sec.myexception.Myexception;
import com.capgemini.sec.service.IService;


@Controller
@Configuration
public class CollegeController {

	@Autowired
	IService service;
	@RequestMapping(value="/create")
	public ModelAndView create_student()
	{
		CollegeModel collegeModel=new CollegeModel();
		return new ModelAndView("application","student",collegeModel);
	}
	
	@RequestMapping(value="/success")
	public ModelAndView add_student(@ModelAttribute(value="student")CollegeModel collegeModel)
	{
		try {
			Integer id=service.create_student(collegeModel);
			return new ModelAndView("success","id",id);
		}catch(Myexception e)
		{
			return new ModelAndView("success","id",e.getMessage());
		}
		
	}
	
}
