package com.capgemini.sec.model;

import javax.persistence.Id;

import org.springframework.stereotype.Component;

@Component
public class CollegeModel 
{
private String name;
@Id
private int id;
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
@Override
public String toString() {
	return "CollegeModel [name=" + name + ", id=" + id + "]";
}
public CollegeModel()
{
	
}
public CollegeModel(String name, int id) {
	super();
	this.name = name;
	this.id = id;
}

}
