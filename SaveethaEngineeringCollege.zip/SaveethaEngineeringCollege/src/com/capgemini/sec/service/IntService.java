package com.capgemini.sec.service;

import com.capgemini.sec.model.CollegeModel;
import com.capgemini.sec.myexception.Myexception;

public interface IntService {

	public Integer create_student(CollegeModel collegeModel)throws Myexception;
	
}
