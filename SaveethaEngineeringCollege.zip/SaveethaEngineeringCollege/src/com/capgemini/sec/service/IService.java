
package com.capgemini.sec.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.sec.dao.IDao;
import com.capgemini.sec.entity.CollegeEntity;
import com.capgemini.sec.model.CollegeModel;
import com.capgemini.sec.myexception.Myexception;

@Service
@Configuration
@Transactional
public class IService implements IntService
{
	@Autowired
	IDao dao;
	public Integer create_student(CollegeModel collegeModel)throws Myexception
	{
		CollegeEntity collegeEntity=new CollegeEntity();
		populate(collegeEntity,collegeModel);
		return dao.create_student(collegeEntity); 
	}
	private void populate(CollegeEntity collegeEntity, CollegeModel collegeModel) {

		collegeEntity.setName(collegeModel.getName());
		collegeEntity.setId(collegeModel.getId());
	}
}
