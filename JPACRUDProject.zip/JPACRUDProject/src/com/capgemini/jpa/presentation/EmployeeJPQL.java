package com.capgemini.jpa.presentation;
import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.capgemini.jpa.entity.Employee;
import com.capgemini.jpa.utility.JPAUtil;
public class EmployeeJPQL {
	public static void main(String[] args)

	{
		EntityManager entityManager=JPAUtil.getEntityManager();
		String jql1 = "SELECT e FROM Employee e";// To Select all employees and display as a list
		TypedQuery<Employee> typedQuery1 = entityManager.createQuery(jql1,Employee.class);
		List<Employee>employeeList=typedQuery1.getResultList();
		showEmployees(employeeList);
		
		
		
		String jql2 = "SELECT e FROM Employee e WHERE e.empid='2'"; //(to select one particular employee)
		TypedQuery<Employee> typedQuery2 = entityManager.createQuery(jql2,Employee.class);
		Employee employee = typedQuery2.getSingleResult();
		System.out.println(employee);
		
		String jql3 = "SELECT e FROM Employee e WHERE e.job=:job";//To get a employee with a condition
		TypedQuery<Employee> typedQuery3 = entityManager.createQuery(jql3,Employee.class);
		typedQuery3.setParameter("job","analyst");
		Employee e=  typedQuery3.getSingleResult();
		System.out.println(e);
		
		
		String jql4 = "SELECT e FROM Employee e WHERE e.job=:pjob AND e.salary>:psalary";//To get a list of employees with 2 r more conditions
		TypedQuery<Employee> typedQuery4 = entityManager.createQuery(jql4,Employee.class);
		typedQuery4.setParameter("pjob","Manager");
		typedQuery4.setParameter("psalary",50000.00);
		List<Employee>employeeList4=typedQuery4.getResultList();
		showEmployees(employeeList4);

		Query query=entityManager.createNamedQuery("q2");//Named query(STATIC QUERY)
		List<Employee>employeeList1=query.getResultList();
		showEmployees(employeeList1);
		
		
		String jql6="select e from Employee e where e.job=?1 AND e.deptno=?2";//Cardinal query
		TypedQuery<Employee>typedQuery=entityManager.createQuery(jql6,Employee.class);
		typedQuery.setParameter(1,"Manager");
		typedQuery.setParameter(2,10);
		List<Employee>employeeList2=typedQuery.getResultList();
		showEmployees(employeeList2);
		
		Query query1=entityManager.createNativeQuery("select * from employee where job=Manager",Employee.class);//Native Query
//		query1.setParameter(1,"Manager");
		List<Employee>employeeList3=query1.getResultList();
		showEmployees(employeeList3);
		
		
	}
//Function to display as a list
	private static void showEmployees(List<Employee> employeeList) {
		Iterator<Employee>iterator=employeeList.iterator();
		while(iterator.hasNext())
		{
			System.out.println(iterator.next());
		}

	}
}
