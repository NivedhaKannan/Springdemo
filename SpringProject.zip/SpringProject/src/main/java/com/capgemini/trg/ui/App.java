package com.capgemini.trg.ui;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.trg.model.Country;


public class App 
{
    public static void main( String[] args )
    {/*
    	@SuppressWarnings("deprecation")
    	XmlBeanFactory beanFactory=new XmlBeanFactory(new ClassPathResource("spring.xml"));*/
    	
    	
    	/*HelloWorld object=(HelloWorld)context.getBean("helloworldBean");
    	System.out.println(object.getMessage());*/
    	ApplicationContext context=new ClassPathXmlApplicationContext("spring.xml");
    /*	CurrencyConverter converter1=(CurrencyConverter) context.getBean("converterBean1");
    	System.out.println("$100=Rs."+converter1.dollarToRupee(100.00));
    	CurrencyConverter converter2=(CurrencyConverter) context.getBean("converterBean2");
    	System.out.println("$100=Rs."+converter2.dollarToRupee(100.00));*/
    	
    	
    	
    	Country country=(Country) context.getBean("countryBean");
    	List<String>countryList=country.getCountryList();
    	Set<String>countrySet=country.getCountrySet();
    	Map<String,String>countryMap=country.getCountryMap();
    	Iterator<String> iterator=countryList.iterator();
    	while(iterator.hasNext())
    	{
    		System.out.println(iterator.next());
    	}
    	System.out.println("-----------------------");
    	
    	//using Stream API
    	countryList.stream().forEach(System.out::println);
    	System.out.println("-----------------------");
    /*	
    	countryList.stream().forEach(s)->(System.out.println(s));
    	System.out.println("-----------------------"); 	*/
    	
    	Iterator<String> iterator1=countrySet.iterator();
    	while(iterator1.hasNext())
    	{
    		System.out.println(iterator1.next());
    	}
     	System.out.println("-----------------------");
    	for(Map.Entry<String,String>m:countryMap.entrySet())
    	{
    		System.out.println(m.getKey()+":"+m.getValue());
    	}
    	((AbstractApplicationContext) context).registerShutdownHook();
    	}
}
