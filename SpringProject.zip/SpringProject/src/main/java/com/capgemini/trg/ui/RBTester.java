package com.capgemini.trg.ui;

import java.util.Enumeration;
import java.util.Locale;
import java.util.ResourceBundle;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;



public class RBTester {
	public static void main(String[]args)
	{
		ApplicationContext context=new ClassPathXmlApplicationContext("spring1.xml");
		
		System.out.println("-------------------------------");
		  Locale currentLocale=Locale.getDefault();
		  System.out.println(currentLocale.getLanguage());
		  System.out.println(currentLocale.getCountry());
		  System.out.println("-------------------------------");
		  //pickup from message.properties
		  String message = context.getMessage("greetings", null, null);
		  System.out.println(message);
		  System.out.println("--------------------------------"); 
//pickup from messsages_fr_FR.poperties
		  message=context.getMessage("greetings", null,Locale.FRANCE);
		  System.out.println(message);
		  System.out.println("---------------------------------");
		  //print by creating Locale variable
		  Locale frenchLocale=new Locale("fr","FR");
		  message=context.getMessage("greetings", null,frenchLocale);
		  System.out.println(message);
		  System.out.println("---------------------------------"); 
ResourceBundle bundle=ResourceBundle.getBundle("messages_fr_FR",frenchLocale);
		  Enumeration enumeration=bundle.getKeys();
		  while(enumeration.hasMoreElements()){
			  String key=(String) enumeration.nextElement();
			  System.out.println(key+"="+bundle.getObject(key));

		  }
	}
	}
	
