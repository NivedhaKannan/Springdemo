package com.capgemini.trg.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.trg.model.HelloWorld;

public class Tester {

	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("test.xml");
		HelloWorld hello=(HelloWorld) context.getBean("helloWorldBean");
	//	HelloWorld hello1=(HelloWorld) context.getBean("helloWorldBean");
		System.out.println(hello.getMessage());
		//System.out.println(hello1.getMessage());
	}

}
