package com.capgemini.trg.model;

public class HelloIndia {
private Message message;

public Message getMessage() {
	return message;
}

public void setMessage(Message message) {
	this.message = message;
}


}
