package com.capgemini.trg.ui;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

public class TestingBean implements InitializingBean,DisposableBean{

	@Override
	public void afterPropertiesSet() throws Exception {
		System.out.println("Initialization before bean instance");
		
	}

	@Override
	public void destroy() throws Exception {

		System.out.println("Clean up before bean destruction");
	}

}
