package com.capgemini.trg.model;

public class Person {
private Long adharCardNumber;
private String name;
private Address residentialAddress;
private Address permanentAddress;
public Person()
{
	
}
public Long getAdharCardNumber() {
	return adharCardNumber;
}
public void setAdharCardNumber(Long adharCardNumber) {
	this.adharCardNumber = adharCardNumber;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public Address getResidentialAddress() {
	return residentialAddress;
}
public void setResidentialAddress(Address residentialAddress) {
	this.residentialAddress = residentialAddress;
}
public Address getPermanentAddress() {
	return permanentAddress;
}
public void setPermanentAddress(Address permanentAddress) {
	this.permanentAddress = permanentAddress;
}
public Person(Long adharCardNumber, String name, Address residentialAddress,
		Address permanentAddress) {
	super();
	this.adharCardNumber = adharCardNumber;
	this.name = name;
	this.residentialAddress = residentialAddress;
	this.permanentAddress = permanentAddress;
}
public void initialize()
{
	System.out.println("Initialization before bean instance");
}
public void cleanup()
{
	System.out.println("Clean up before bean destruction");
}
}
