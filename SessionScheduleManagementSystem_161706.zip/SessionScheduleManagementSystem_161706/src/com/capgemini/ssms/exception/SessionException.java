package com.capgemini.ssms.exception;

public class SessionException extends Exception{
	private static final long serialVersionUID = 1L;
	
	public String message;
	public SessionException(String message) {
		this.message = message;
	}
	
	public String getMessage() {
		return message;
	}
}
