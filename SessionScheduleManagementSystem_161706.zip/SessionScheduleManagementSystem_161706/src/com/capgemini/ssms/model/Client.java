package com.capgemini.ssms.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="scheduledsessions")
public class Client
{
	
@Id
Integer id;//primary key

@NotNull
String name;
Integer duration;
String faculty;
Integer mode1;

public Client()
{
	
}
public Integer getId() {
	return id;
}
public void setId(Integer id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public Integer getDuration() {
	return duration;
}
public void setDuration(Integer duration) {
	this.duration = duration;
}
public String getFaculty() {
	return faculty;
}
public void setFaculty(String faculty) {
	this.faculty = faculty;
}
public Integer getMode1() {
	return mode1;
}
public void setMode1(Integer mode1) {
	this.mode1 = mode1;
}
public Client(Integer id, String name, Integer duration, String faculty, Integer mode1) {
	super();
	this.id = id;
	this.name = name;
	this.duration = duration;
	this.faculty = faculty;
	this.mode1 = mode1;
}


}
