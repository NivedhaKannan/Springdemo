package com.capgemini.ssms.dao;


import java.util.ArrayList;


import com.capgemini.ssms.exception.SessionException;
import com.capgemini.ssms.model.Client;

public interface ITrainingDAO 
{
	//method to get the list from database
	public ArrayList<Client> getSessionTable() throws SessionException;

	}
