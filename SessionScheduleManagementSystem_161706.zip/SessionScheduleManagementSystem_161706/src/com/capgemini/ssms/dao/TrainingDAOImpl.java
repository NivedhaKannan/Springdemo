package com.capgemini.ssms.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.ssms.exception.SessionException;
import com.capgemini.ssms.model.Client;
@Repository
@Transactional
public class TrainingDAOImpl implements ITrainingDAO

{
	@Autowired
	//object of entityManager
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public ArrayList<Client> getSessionTable()throws SessionException
	{
		try
		{
			// ArrayList to create the list from database
			ArrayList<Client> list = new ArrayList<>();
			String jpql = "Select client from Client client";//Selects every row in the table
			TypedQuery<Client> query = entityManager.createQuery(jpql, Client.class);
			list = (ArrayList<Client>) query.getResultList();//TypeCasting from entity to model
			return list;
			//List with session details

		}catch(PersistenceException e)
		{
			throw new SessionException(e.getMessage());
		}
	}
}
