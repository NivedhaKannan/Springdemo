package com.capgemini.ssms.service;


import java.util.ArrayList;

import com.capgemini.ssms.exception.SessionException;
import com.capgemini.ssms.model.Client;

public interface ITrainingService 
{
	//method to get the list from database
	public ArrayList<Client> getSessionTable()throws SessionException;
}
