package com.capgemini.ssms.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.ssms.exception.SessionException;
import com.capgemini.ssms.model.Client;
import com.capgemini.ssms.service.ITrainingService;

@Controller
@RequestMapping(value="/training")
public class TrainingController {

	//object of Service class
	@Autowired
	ITrainingService trainingService;

	//To direct to the table view page
	@RequestMapping(value="/home",method=RequestMethod.GET)//from index
	public ModelAndView getAllSessions() throws SessionException
	{
		List<Client>clientList=new ArrayList<Client>(); 
		clientList=trainingService.getSessionTable();
		return new ModelAndView("ScheduledSessions", "clientList", clientList);
	}


	//To direct to the Enroll page

	@RequestMapping(value="/Enroll Me",method=RequestMethod.GET)//Link from scheduled sessions page
	public ModelAndView display(@RequestParam("name") String name)//RequstParameter to get a value from home page
	{
		return new ModelAndView("Success", "name", name);
	}
}
